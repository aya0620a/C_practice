#include<stdio.h>
#include<math.h>

int main(void){
	int a, b, c;
	int cz;
	double dis;
	scanf("%d %d %d", &a, &b, &c);
	
	cz = fabs(c);
	
	dis = cz / sqrt(a*a + b * b);
	
	
	if(dis < 1.0){
		printf("a = %d, b = %d, c = %d のとき\n", a, b, c);
		printf("%f, 原点に近い\n", dis);
	}
	
	else if(dis <3.0){
		printf("a = %d, b = %d, c = %d のとき\n", a, b, c);
		printf("%f ,いずれでもない", dis);
	}
	
	else{
		printf("a = %d, b = %d, c = %d のとき\n", a, b, c);
		printf("%f , 原点から遠い", dis);
	}
	

	return 0;
}