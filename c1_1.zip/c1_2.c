#include<stdio.h>

int main(void){
	printf("1\n");
	for(int i = 9; i >= 1; i-- ){
		printf("%3d", 9 * i);
	}
	
	printf("\n");
	printf("\n");
	printf("2\n");
	for(int i = 9; i >= 1; i--){
		for (int j = 9; j >= 1; j--){
			printf("%3d", i * j);
		}
		printf("\n");
		}
	
	return 0;
}