#include<stdio.h>

int discriminant(int a, int b, int c){
	int d;
	d = b * b - 4 * a * c;
	
	return d;
}

int solutions(int a, int b, int c){
	int count;
	int d = discriminant(a, b, c);
	
	if(d > 0){
		count = 2;
	}
	else if(d < 0){
		count = 0;
	}
	else{
		count = 1;
	}
	
	return count;
}

int main(void){
	int u, v, w;
	scanf("%d %d %d", &u, &v, &w);
	int count;
	
	count = solutions(u, v, w);
	printf("u = %d, v = %d, w = %d のとき\n", u, v, w);
	printf("判別式は %d , 実数解は%d 個\n", discriminant(u, v, w), count);

	int a, b, c;
	scanf("%d %d %d",  &a, &b, &c);
	
	if (a == 0 && b == 0){
		printf("不適切な入力です");
	}
	
	else{
		printf("a = %d, b = %d, c = %d のとき\n", a, b, c);
		printf("実数解は%d 個", solutions(a, b, c));
	}
	
	return 0;
}
	