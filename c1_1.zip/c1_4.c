# include<stdio.h>
# define N 8

int main(void){
	int n;
	int count;
	int total;
	double totala;
	scanf("%d", &n);
	printf("n = %d を入力したとき\n", n);
	int score[N];
	
	int e[7] = {60 ,85, 55, 30, 45, 50, 90};
	int m[7] = {70 ,60, 30, 90, 70, 55, 70};
	
	for(int i = 0; i < N - 1; i++){
		score[i] = e[i] + m[i];
		printf("score[%d] = %3d \n", i, score[i]);
	}
	
	for(int i = 0; i < N - 1; i++){
		total += score[i];
		
		if(score[i] >= n){
			count++;
		}
	}
	
	totala = (double)total / 7;
	printf("合格者 %d 名\n", count);
	printf("合格者平均点 %f\n", totala);
	
	return 0;
}