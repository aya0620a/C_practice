#include<stdio.h>

int main(void)
{
int a = 1234;
int b = 5678;
int c = 7777;

printf("a = %p\n",&a);
printf("b = %p\n",&b);
printf("c = %p\n",&c);
	
return 0;
}